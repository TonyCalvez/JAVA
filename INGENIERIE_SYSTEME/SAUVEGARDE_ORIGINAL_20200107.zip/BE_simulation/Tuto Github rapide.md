# Tuto Github rapide

Concrètement :

- Le projet final est dans la branche _master_ de mon repository _github_
- Vous devez avoir forké mon repository.

Pour l'utilisation :

- Lorsque vous voulez rajouter une fonctionalité. Vous commencez par créer une nouvelle branche. Vous pouvew le faire à partir du menu (_VCS/Git/Branch..._) ou avec la commande `git -b checkout <nomDeMaNouvelleBranche>` (cette commande change la branche courante vers celle qui est donnée et la crée si vlus lui donnez l'argument -b elle existe pas). Pour voir la branche courante utilisez la commande `git branch` et regardez le nom qui commence par un \*.
- Vous développer votre truc dans votre nouvelle branche jusqu'a avoir un truc propre qui marche. 
- Vous commitez vos changements dans votre branche de développement (click droit sur le projet, _commit directory_ ou `git commit -a -m "Mon message de commit`). Vous pouvez commitez autant que vous voulez, ca ne change rien sur votre github, ça ne sert qu'a pouvoir revenir en arrière si vous faite une connerie.
- Quand vous voulez mettre à jour votre branche de développement dans votre github vous faite un push (soit avec le menu _VCS/Git/Push..._ soit avec la commande `git push origin <nomDeMaBrancheDeDeveloppement>`).
- Quand tout fonctionne, vous pouvez mettre à jour votre branche _master_ locale. Pour ça, mettez vous sur la branche _master_ avec `git checkout master` puis faite un merge (menu _VCS/Git/Merge Changes_ ou `git merge <nomDeMaBrancheDeDeveloppement>`).
- Vous pouvez ensuite mettre à jour la branche *master* de votre github en ligne avec un push.
- C'est le moment de faire une requete pour mettre a jour le projet final. Pour ça allez sur Github, mettez vous la branche *master* de votre Github et cliquer sur new pull Request. Une fois que la requête est traitée (_closed_), il faut mettre à jour votre branch _master_ avec la nouvelle branche _master_ de projet final. Pour ça allez dans IntelliJ et clickez sur _VCS/Git/Update Project_. Attention à bien etre dans votre branche master quand vous mettez à jour sinon ça ne marchera pas.

Pensez à faire des mises à jour régulière de votre branche master.
