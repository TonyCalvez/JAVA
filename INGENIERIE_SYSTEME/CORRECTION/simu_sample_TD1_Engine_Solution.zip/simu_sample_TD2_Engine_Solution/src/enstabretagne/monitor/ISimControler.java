/**
* Classe ISimControler.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.monitor;

/**
 * The Interface ISimControler.
 */
public interface ISimControler {

}

