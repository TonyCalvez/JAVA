/*
 * 
 */
package enstabretagne.simulation.core;

// TODO: Auto-generated Javadoc
/**
 * The Interface FunctionalSimObjectRequest.
 */
@FunctionalInterface
public interface FunctionalSimObjectRequest {
	
	/**
	 * Filter.
	 *
	 * @param o the o
	 * @return true, if successful
	 */
	boolean filter(ISimObject o);
}
