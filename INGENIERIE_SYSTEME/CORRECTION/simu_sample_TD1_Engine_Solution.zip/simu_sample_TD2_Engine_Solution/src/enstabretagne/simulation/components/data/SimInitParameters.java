/**
* Classe SimInitParameters.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.simulation.components.data;

/**
 * The Class SimInitParameters.
 */
public abstract class SimInitParameters {

}

