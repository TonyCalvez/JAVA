/**
* Classe MessagesDictionnary.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.base.messages;

// TODO: Auto-generated Javadoc
/**
 * The Class MessagesDictionnary.
 */
public class MessagesDictionnary {

	/** The Constant NewClassObjectAdded. */
	public static final String NewClassObjectAdded = "Nouvelle classe d'objet ajout�e : %s";
	
	/** The Constant NewObjectAdded. */
	public static final String NewObjectAdded = "Nouvel Objet ajout� : %s";
	
	/** The Constant ObjectTypeNotReferenced. */
	public static final String ObjectTypeNotReferenced = "Type d'objet non r�f�renc� dans le dictionnaire : %s";
	
}

